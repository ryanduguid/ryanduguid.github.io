# Lumbridge scenario exercise

This guide explains how to explore the synthetic cash-flow case.
No OSRS knowledge is needed. Varrock and Falador are the two service lines;
the Grand Exchange reference means customer collections.

Use a fresh copy of `lumbridge.xlsx`, its source files and this guide.
You do not need a Xero login, client data, macros or an AI agent.

## First run

If you received the workbook, open it in desktop Excel and enable automatic
calculation. Do not enable macros or external links. If you are reproducing
from source, follow the two commands in MODEL-NOTES.md first.

1. Find the October to December revenue, profit before income tax and
   December closing cash. Identify which amounts are forecasts.
2. Find the lowest daily closing cash balance and the date it occurs.
   Explain why looking only at December cash could miss a funding problem.
3. Find invoice OPEN-V in `data/invoices.csv`. Trace its amount and receipt
   date into the workbook.
4. Change the receipt-delay control from 0 to 45 calendar days. Record the
   lowest daily balance, first negative date and October closing cash.
   State whether profit changed and explain the difference.
5. Identify the outstanding December GST, supplier and PAYG withholding
   balances. Explain why gross wages and net employee bank payments differ.
6. Check the profit-to-cash reconciliation for all three months. Explain
   how non-cash leave, customer debtors and tax payments enter the bridge.
7. Recommend one action for the owner before approving discretionary
   equipment spending. A dragon pickaxe is the fictional equipment upgrade.
8. Restore the delay to zero, save your copy, close and reopen it.
   Confirm the original results return.

The workbook's only supported scenario control is `Assumptions!B2`.
Blank cells in January's closing-cash column are intentional: future
invoice dates support receivables, but January payments are outside the forecast.
MODEL-NOTES.md states the model's limits and source assumptions.
